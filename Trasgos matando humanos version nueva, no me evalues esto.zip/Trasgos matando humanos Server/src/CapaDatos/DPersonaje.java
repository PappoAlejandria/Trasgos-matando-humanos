package CapaDatos;

public class DPersonaje { // Los personajes tienen movimientos limitados por turno, y solamente pueden atacar una vez.

	private DDado dmgPj;
	private int vidaPj;
	private int movimientos;
	private int atkPj;
	private int chapa;
	private int ataques;
	
	private int movRestantes;
	private int vidaRestante;
	private int ataquesRestantes;
	
	
	public DPersonaje(int atk, DDado dmg, int atks, int ca, int vida, int movimientos) {
		this.atkPj = atk;
		this.dmgPj = dmg;
		this.chapa = ca;
		this.vidaPj = vida;
		this.movimientos = movimientos;
		this.ataques = atks;
		this.movRestantes = this.getMovimientos();
		this.vidaRestante = this.getVidaPj();
		this.ataquesRestantes = this.getAtaques();
	}
	
	public int getAtaquesRestantes() {
		return ataquesRestantes;
	}

	public void setAtaquesRestantes(int ataquesRestantes) {
		this.ataquesRestantes = ataquesRestantes;
	}

	public int getAtaques() {
		return ataques;
	}

	public int getAtkPj() {
		return atkPj;
	}

	public int getChapa() {
		return chapa;
	}

	public DDado getDmgPj() {
		return dmgPj;
	}

	public void setDmgPj(DDado dmgPj) {
		this.dmgPj = dmgPj;
	}

	public int getVidaPj() {
		return vidaPj;
	}

	public void setVidaPj(int vidaPj) {
		this.vidaPj = vidaPj;
	}

	public int getMovimientos() {
		return movimientos;
	}

	public void setMovimientos(int movimientos) {
		this.movimientos = movimientos;
	}

	public int getMovRestantes() {
		return movRestantes;
	}

	public void setMovRestantes(int movRestantes) {
		this.movRestantes = movRestantes;
	}
	
	public int getVidaRestante() {
		return vidaRestante;
	}

	public void setVidaRestante(int vidaRestante) {
		this.vidaRestante = vidaRestante;
	}
	
	public String toString() {
		return "Ataque: +" + this.atkPj + ", Da�o: " + this.dmgPj.toString() + ", CA: " + this.chapa + ", Vida: " + this.vidaRestante + "/" + this.vidaPj + ", Movimientos: " + this.movRestantes + "/" + this.movimientos + ", Ataques: " + this.ataquesRestantes + "/" + this.ataques;
	}
}
