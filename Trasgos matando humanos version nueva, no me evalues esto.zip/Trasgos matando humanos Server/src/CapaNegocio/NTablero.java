package CapaNegocio;

import java.util.ArrayList;
import java.util.List;

import CapaDatos.DCasilla;
import CapaDatos.DTablero;

public class NTablero extends DTablero {
	
	public NTablero(List<DCasilla> cas) {
		super(cas);
	}

	public static NTablero generarTablero(int posXMax, int posYMax) { // Genera un tablero cuadrado. Es un m�todo conveniente.
		int i = 0;
		int j = 0;
		List<DCasilla> casillas = new ArrayList<DCasilla>();
		while(i < posXMax) {
			j=0;
			while(j < posYMax) {
				casillas.add(new DCasilla(i, j));
				j++;
			}
			i++;
		}
		return new NTablero(casillas);
	}
	
	public void ponerPersonaje(NPersonaje pj, int x, int y) { // Pone un personaje en una casilla del tablero. Si no existe la casilla no hace nada.
		for(DCasilla casilla : this.getCasillas()) {
			if(casilla.getPosX() == x && casilla.getPosY() == y) {
				casilla.setPj(pj);
			}
		}
	}
	
	public List<DCasilla> getAdyacentes(int x, int y){ // Devuelve las casillas adyacentes a una concreta. Necesario, porque los personajes solamente pueden interactuar con estas casillas.
		List<DCasilla> ady = new ArrayList<DCasilla>();
		
		for(DCasilla casilla : this.getCasillas()) {
			if((x-1 <= casilla.getPosX() && casilla.getPosX() <= x+1)
					&& (y-1 <= casilla.getPosY() && casilla.getPosY() <= y+1)
					&& !(casilla.getPosX() == x && casilla.getPosY() == y))
				ady.add(casilla);
		}
		
		return ady;
	}
	
	public List<DCasilla> getAdyacentesRango(int x, int y, int rango){ // Devuelve las casillas a una cierta distancia de una concreta.
		List<DCasilla> adyEnRng = getAdyacentes(x, y);
		int i = 1;
		int xx;
		int yy;
		
		while(i < rango) {
			for(DCasilla casYaEnAdy : adyEnRng) {
				xx = casYaEnAdy.getPosX();
				yy = casYaEnAdy.getPosY();
				for(DCasilla casilla : this.getCasillas()) {
					if(!adyEnRng.contains(casilla)
							&& (xx-1 <= casilla.getPosX() && casilla.getPosX() <= xx+1)
							&& (yy-1 <= casilla.getPosY() && casilla.getPosY() <= yy+1)
							&& !(casilla.getPosX() == xx && casilla.getPosY() == yy))
						adyEnRng.add(casilla);
				}
			}
		}
		
		return adyEnRng;
	}
	
	public void limpiarTablero() { // Quita los personajes de todas las casillas del tablero.
		for(DCasilla casilla : this.getCasillas()) {
			casilla.setPj(null);
		}
	}
}
