package CapaNegocio;

import CapaDatos.DDado;
import CapaDatos.DPersonaje;

public class NPersonaje extends DPersonaje { // Wrapper en capa de negocio

	public NPersonaje(int atk, DDado dmg, int atks, int ca, int vida, int movimientos) {
		super(atk, dmg, atks, ca, vida, movimientos);
	}
	
	public boolean puedeAtacar() {
		return this.getAtaquesRestantes() > 0;
	}
}
