package CapaNegocio;

import CapaDatos.DDado;
import CapaDatos.DJugador;

public class NJugador extends DJugador{
	
	public NJugador(String nombre) {
		super(nombre);
	}
	
	public void rollIniciativa() { // La iniciativa determina qu� jugador va primero
		this.setIniciativa((new NDado(new DDado(1, 20))).rollD());
	}
}
