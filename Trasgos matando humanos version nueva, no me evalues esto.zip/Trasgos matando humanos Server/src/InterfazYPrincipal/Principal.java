package InterfazYPrincipal;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

import CapaDatos.DCasilla;
import CapaDatos.DDado;
import CapaNegocio.NJuego;
import CapaNegocio.NJugador;
import CapaNegocio.NPersonaje;
import CapaNegocio.NTablero;

public class Principal {

	public static void main(String[] args) {
		NTablero tablero = NTablero.generarTablero(6, 6);

		Scanner lector = new Scanner(System.in);
		
		try(ServerSocket ss = new ServerSocket(7777);){
			while(true) {
				try(Socket sc = ss.accept();
						DataInputStream is = new DataInputStream(new BufferedInputStream(sc.getInputStream()));
						DataOutputStream os = new DataOutputStream(new BufferedOutputStream(sc.getOutputStream()));){
					
					System.out.println("Conectado.");
					
					tablero.limpiarTablero(); // Quitamos todos los personajes del tablero
					
					// Inicializamos los datos del DM (Dungeon Master)
					NJugador master = new NJugador("Master");
					NPersonaje bicho = new NPersonaje(12, new DDado(12,20), 4, 24, 800, 6);
					master.addPj(bicho);
					
					
					
					tablero.ponerPersonaje(bicho, 0, 0);
					
					String pjEntrante;
					
					// Inicializamos los datos del jugador entrante
					pjEntrante = is.readLine();
					String[] param = pjEntrante.split(",");
					String[] datosDado = param[2].split("d");

					NJugador jugador = new NJugador(param[0]);
					
					NPersonaje bichoJ = new NPersonaje(Integer.parseInt(param[1]), new DDado(Integer.parseInt(datosDado[0]), Integer.parseInt(datosDado[1])), Integer.parseInt(param[3]), Integer.parseInt(param[4]), Integer.parseInt(param[5]), Integer.parseInt(param[6]));
					jugador.addPj(bichoJ);
					
					tablero.ponerPersonaje(bichoJ, 5, 5);
					
					// Describimos al personaje entrante
					System.out.println("Personaje entrante: " + bichoJ.toString());
					
					// Empezamos
					NJuego juego = new NJuego(tablero, master, jugador);

					// Mostramos las iniciativas por pantalla. La iniciativa se determina con un dado de 20 caras. El que saque m�s alto empieza.
					int iniMaster = master.getIniciativa();
					int iniJugador = jugador.getIniciativa();
					
					System.out.println("Empezando el juego. Iniciativas:");
					System.out.println(master.getNombre() + ": " + iniMaster);
					System.out.println(jugador.getNombre() + ": " + iniJugador);
					
					String mensajeBienvenida = "Empezando el juego. Iniciativas:\n" + master.getNombre()+ ": " + iniMaster + "\n" + jugador.getNombre() + ": " + iniJugador + "\n";
					
					if(iniMaster > iniJugador) {
						System.out.println("Empieza el DM");
						mensajeBienvenida += "Empieza el DM\n";
					}
					else {
						System.out.println("Empieza el jugador");
						mensajeBienvenida += "Empieza el jugador\n";
					}
					
					os.write(mensajeBienvenida.getBytes());
					os.flush();
					
					int i = 0;
					String mensaje;
					String movimiento;
					DCasilla casPJ;

					// Bucle principal. Ambas opciones son equivalentes en su funci�n y como tal probablemente puedan compactarse en una sola.
					while(!juego.isAcabado()) {
						// Turno del DM
						if(juego.getTurno() == 0) {
							// Descripcion de la situacion
							casPJ = tablero.getCasillaJugador(bicho);
							System.out.println("Tu personaje se halla en " +
									casPJ.toString());
							System.out.println("Las estad�sticas de tu personaje son " + bicho.toString());
							System.out.println("El personaje de tu rival se halla en " +
									tablero.getCasillaJugador(bichoJ).toString());
							System.out.println("Las estad�sticas del personaje de tu rival son " + bichoJ.toString());
							System.out.print("Puedes mover a ");
							for(DCasilla casilla : tablero.getAdyacentes(casPJ.getPosX(), casPJ.getPosY())) {
								System.out.print(casilla.toString() + "(" + i + "), ");
								i++;
							}
							i=0;
							System.out.println("o pasar turno (p)");
							System.out.println();
							// Leemos movimiento
							movimiento = lector.nextLine();
							// Ejecutamos movimiento o pasamos turno
							if(tryParseInt(movimiento)) {
								juego.hacerUnMovimiento(Integer.parseInt(movimiento));
							}
							else {
								juego.pasarTurno();
							}
						}
						// Turno del jugador
						else {
							casPJ = tablero.getCasillaJugador(bichoJ);
							mensaje = "";
							mensaje += "Tu personaje se halla en " +
									casPJ.toString() + "\n";
							mensaje += "Las estad�sticas de tu personaje son " + bichoJ.toString() + "\n";
							mensaje += "El personaje de tu rival se halla en " + tablero.getCasillaJugador(bicho).toString() + "\n";
							mensaje += "Las estad�sticas del personaje de tu rival son " + bicho.toString() + "\n";
							mensaje += "Puedes mover a ";

							for(DCasilla casilla : tablero.getAdyacentes(casPJ.getPosX(), casPJ.getPosY())) {
								mensaje += casilla.toString() + "(" + i + "), ";
								i++;
							}
							i=0;
							
							mensaje += "o pasar turno (p)\n\n";
							
							os.write(mensaje.getBytes());
							os.flush();
							
							movimiento = is.readLine();

							if(tryParseInt(movimiento)) {
								juego.hacerUnMovimiento(Integer.parseInt(movimiento));
							}
							else {
								juego.pasarTurno();
							}
						}
					}
					
					// Acaba el juego y declaramos ganador.
					mensaje = "El juego ha acabado. Ha ganado " + (juego.getTurno()==0 ? master.getNombre() : jugador.getNombre()) + ".\n";
					os.write(mensaje.getBytes());
					os.flush();
					System.out.println(mensaje);
				}
				catch(IOException ee) {
					ee.printStackTrace();
				}
			}
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		
		lector.close();
	}
	
	private static boolean tryParseInt(String value) {  
	     try {  
	         Integer.parseInt(value);  
	         return true;  
	      } catch (NumberFormatException e) {  
	         return false;  
	      }  
	}
}
